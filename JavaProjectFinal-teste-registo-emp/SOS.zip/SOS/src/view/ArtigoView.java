package view;

public class ArtigoView {
	
	public static void RegistosArtigosView()
	{
	System.out.println("-----------------------------------");
	System.out.println("         Registar Artigo           ");
	System.out.println("-----------------------------------");
	System.out.println("1- Registar um Livro               ");
	System.out.println("2- Registar um DVD                 ");
	System.out.println("3- Registar um Equipamento         ");
	System.out.println("4- Registar uma Ferramenta         ");
	System.out.println("5- Registar Outro                  ");
	System.out.println("6- Retroceder                      ");
	System.out.println("7- Sair                            ");
	System.out.println("-----------------------------------");
	System.out.println("Selecione uma op��o:               ");
	}
			
}
